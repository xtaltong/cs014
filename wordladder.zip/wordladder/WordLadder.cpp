#include "WordLadder.h"
#include<istream>
#include<iostream>
#include<ostream>
#include<fstream>
#include<queue> 
#include<stack>
#include<string>
#include<vector>
#include<list>

using namespace std;

WordLadder::WordLadder(const string &filename){
    ifstream fin;
    string word = "";
    fin.open(filename);
    if (!fin.is_open()){
        cout << "Error opening file: " << filename << endl; 
    }
    
    while(fin >> word){
        if (word.length() != 5){
            cout << "Error. Word contained more than 5 characters." << endl;
            return;
        }
        dict.push_back(word);
    }
}

void WordLadder::outputLadder(const string &start, const string &end, const string &outputFile){
    ofstream fout;
    queue< stack<string> > qofstacks;
    stack<string> stringStack;
    string word;
    list<string>::iterator i;
    bool startexists = false;
    bool endexists = false;
    fout.open(outputFile);
    
    if(!fout.is_open()){
        cout << "Error opening: " << outputFile << endl;
        return;
    }
    
    for(i = dict.begin(); i != dict.end(); ++i){
        if(*i == start){
            startexists = true;
        }
        if (*i == end){
            endexists = true;
        }
    }
    
    if(!startexists || !endexists){
        cout << "Start word or End word not found." << endl;
    }
    
    if(start == end){
        fout << start;
        return;
    }
    
    stringStack.push(start);
    qofstacks.push(stringStack);
    
    dict.remove(start);
    
    while(!qofstacks.empty()){
        word = qofstacks.front().top(); //gets the front of q then top of stack
        for ( i = dict.begin(); i != dict.end(); ++i){
            if(checkLetters(word, *i)){                 //checks if words are 1 letter off
                if(*i == end){                          //if end is reached
                    qofstacks.front().push(end);          //get the front, push the end to the top of the stack
                    displayStack(qofstacks.front(), fout);
                    return;
                }
                stringStack = qofstacks.front(); 
                stringStack.push(*i);
                qofstacks.push(stringStack);    //place stack in q
                i = dict.erase(i);  //go to next word
                i--;                //adjust iterator
            }
        }
        qofstacks.pop();        //dequeue front stack
    }
    
    if(fout.is_open()){
        fout << "No Word Ladder Found." << endl;
    }
    
    fout.close();
}

bool WordLadder::checkLetters(const string &word1, const string &word2){
    int check = 0;
    for (unsigned i = 0; i < 5; ++i){
        if(word1.at(i) != word2.at(i) ){
            ++check;
        }
    }
    if(check == 1){
        return true;
    }
    else{
        return false;
    }
}

void WordLadder::displayStack(stack<string> stringStack, ofstream &fout){
    vector<string> words;
       
    while(!stringStack.empty()){
       words.push_back(stringStack.top());
       stringStack.pop();
    }
    
    if(fout.is_open()){
        for(int i = words.size() - 1; i >= 0; --i){
            fout << words.at(i);
           
            if (i != 0){
               fout << " ";
            }
        }
    }
}